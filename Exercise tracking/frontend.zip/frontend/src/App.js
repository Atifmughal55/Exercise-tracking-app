import Footer from "./components/Footer";
import Navbar from "./components/Navbar";
import Card from "./pages/Card";
import CardList from "./pages/CardList";
import History from "./pages/History";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import { Routes, Route } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import UpdatCard from "./pages/UpdatCard";

function App() {
  return (
    <div className="App">
      <Navbar />
      <Routes>
        <Route element={<ProtectedRoute />}>
          <Route path="/card" element={<Card />} />
          <Route path="/cardlist" element={<CardList />} />
          <Route path="/history" element={<History />} />
          <Route path="/updateTask/:id" element={<UpdatCard />} />
        </Route>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Signup />} />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
