import React from "react";
import "./Choseus.css";

const Choseus = () => {
  return (
    <div>
      <section id="chose" class="choseus-section spad">
        <div class="container ">
          <div class="row">
            <div class="col-lg-12">
              <div class="section-title text-center my-4 text-white">
                <span>Why chose us?</span>
                <h3>PUSH YOUR LIMITS FORWARD</h3>
              </div>
            </div>
          </div>
          <div class="row ">
            <div class="col-lg-4 col-sm-6">
              <div class="cs-item p-4 ">
                <h4>Best Health Diet</h4>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut dolore facilisis.
                </p>
              </div>
            </div>
            <div class="col-lg-4 col-sm-6">
              <div class="cs-item p-4 my-5">
                <h4>Expert Trainers</h4>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut dolore facilisis.
                </p>
              </div>
            </div>
            <div class="col-lg-4 col-sm-6">
              <div class="cs-item p-4 my-5">
                <h4>Modern Equipment</h4>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut dolore facilisis.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Choseus;
