import React from "react";
import "./Services.css";
const Services = () => {
  return (
    <div>
      <section class="classes-section spad" id="service">
        <div class="container mb-4">
          <div class="row">
            <div class="col-lg-12">
              <div class="section-title text-center text-white ">
                <span>Our Classes</span>
                <h2>WHAT WE CAN OFFER</h2>
              </div>
            </div>
          </div>
          <div class="row d-flex justify-content-center mb-4">
            <div class="col-md-10">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-4 d-flex justify-content-center align-items-center mb-3 mb-lg-0">
                      <img
                        src="https://images.unsplash.com/photo-1594882645126-14020914d58d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=885&q=80"
                        class="img-fluid shadow-1"
                        alt="woman avatar"
                        width="300"
                        height="300"
                      />
                    </div>
                    <div class="col-lg-8">
                      <p class="fw-bold lead mb-2">
                        <strong>Running</strong>
                      </p>
                      <p class="fw-bold text-muted mb-0"></p>
                      <p class="text-muted fw-light mb-3">
                        Lorem ipsum dolor, sit amet consectetur adipisicing
                        elit. Id quam sapiente molestiae numquam quas,
                        voluptates omnis nulla ea odio quia similique corrupti
                        magnam.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row d-flex justify-content-center mb-4">
            <div class="col-md-10">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-8">
                      <p class="fw-bold lead mb-2">
                        <strong>Swiming</strong>
                      </p>
                      <p class="fw-bold text-muted mb-0"></p>
                      <p class="text-muted fw-light mb-3">
                        Lorem ipsum dolor, sit amet consectetur adipisicing
                        elit. Id quam sapiente molestiae numquam quas,
                        voluptates omnis nulla ea odio quia similique corrupti
                        magnam.
                      </p>
                    </div>
                    <div class="col-lg-4 d-flex justify-content-center align-items-center mb-3 mb-lg-0">
                      <img
                        src="https://images.unsplash.com/photo-1600965962361-9035dbfd1c50?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80"
                        class="img-fluid shadow-1"
                        alt="woman avatar"
                        width="300"
                        height="300"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row d-flex justify-content-center mb-4">
            <div class="col-md-10">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-4 d-flex justify-content-center align-items-center mb-3 mb-lg-0">
                      <img
                        src="https://plus.unsplash.com/premium_photo-1684274186183-a436f2458aa4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=870&q=80"
                        class="img-fluid shadow-1"
                        alt="woman avatar"
                        width="300"
                        height="300"
                      />
                    </div>
                    <div class="col-lg-8">
                      <p class="fw-bold lead mb-2">
                        <strong>Cycling</strong>
                      </p>
                      <p class="fw-bold text-muted mb-0"></p>
                      <p class="text-muted fw-light mb-3">
                        Lorem ipsum dolor, sit amet consectetur adipisicing
                        elit. Id quam sapiente molestiae numquam quas,
                        voluptates omnis nulla ea odio quia similique corrupti
                        magnam.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
