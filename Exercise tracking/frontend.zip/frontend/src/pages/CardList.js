import React, { useEffect, useState } from "react";
import "./CardList.css";
import { Link } from "react-router-dom";

const CardList = () => {
  const auth = localStorage.getItem("user");
  const user = JSON.parse(auth);

  const [task, setTask] = useState([]);

  const todoComplete = async (id) => {
    let result = await fetch(`http://localhost:8080/activitycomplete/${id}`, {
      method: "PUT",
    });
    result = await result.json();
    getTasks();
  };

  const getTasks = async () => {
    let tasks = await fetch(`http://localhost:8080/activities/${user._id}`);
    tasks = await tasks.json();
    setTask(tasks);
  };

  // console.log(todos);
  useEffect(() => {
    getTasks();
  }, []);
  return (
    <div>
      <section
        class=" mt-0 d-flex"
        style={{
          minHeight: "100vh",
          backgroundSize: "cover",
          backgroundImage:
            "url(https://images.pexels.com/photos/1552249/pexels-photo-1552249.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1)",
          backgroundAttachment: "fixed",
        }}
      >
        <div class="container mt-5 mb-3">
          <div class="col-md-12 text-center text-white my-4">
            <h2>My Activities</h2>
          </div>
          <div class="row">
            {task.map((tas, ind) => {
              return (
                <div class="col-md-4">
                  <div class="card p-3 mb-2">
                    <div class="d-flex justify-content-between">
                      <div class="d-flex flex-row align-items-center">
                        <div class="ms-2 c-details">
                          <span className="mx-3">{tas.date}</span>
                          <h3 class="mx-3">{tas.activity}</h3>
                        </div>
                      </div>
                      <div class="badge">
                        <span>{tas.duration} min</span>
                      </div>
                    </div>
                    <div class="mt-3 mx-3">
                      <h5 class="heading text-white">{tas.description}</h5>
                      <div class="mt-3">
                        <div class="progress">
                          <div
                            class="progress-bar"
                            role="progressbar"
                            style={{ width: "100%" }}
                            aria-valuenow="100"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          ></div>
                        </div>
                        <div class="mt-3 d-flex justify-content-between">
                          <Link
                            to={`/updateTask/${tas._id}`}
                            style={{ color: "black" }}
                          >
                            <i
                              class="fa-solid fa-pencil fa-lg"
                              style={{ cursor: "pointer" }}
                            ></i>
                          </Link>

                          <i
                            class="fa-regular fa-square-check fa-lg"
                            style={{ cursor: "pointer" }}
                            onClick={() => todoComplete(tas._id)}
                          ></i>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

export default CardList;
