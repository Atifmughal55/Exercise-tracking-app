import React, { useEffect, useState } from "react";

const History = () => {
  const auth = localStorage.getItem("user");
  const user = JSON.parse(auth);
  const [task, setTask] = useState([]);

  const deleteTask = async (id) => {
    let result = await fetch(`http://localhost:8080/activity/${id}`, {
      method: "delete",
    });

    result = await result.json();
    if (result) {
      getTasks();
    }
  };

  const getTasks = async () => {
    let tasks = await fetch(`http://localhost:8080/activity/${user._id}`);
    tasks = await tasks.json();
    // console.log(tasks[0]);
    setTask(tasks);
  };
  useEffect(() => {
    getTasks();
  }, []);
  return (
    <div>
      <section
        class=" mt-0 d-flex"
        style={{
          minHeight: "100vh",
          backgroundSize: "cover",
          backgroundImage:
            "url(https://images.pexels.com/photos/1552249/pexels-photo-1552249.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1)",
          backgroundAttachment: "fixed",
        }}
      >
        <div class="container mt-5 mb-3">
          <div class="row">
            <div class="col-md-12 text-center text-white my-4">
              <h2>History</h2>
            </div>
            {task.map((tas, ind) => {
              return (
                <div class="col-md-4">
                  <div class="card p-3 mb-2">
                    <div class="d-flex justify-content-between">
                      <div class="d-flex flex-row align-items-center">
                        <div class="ms-2 c-details">
                          <span className="mx-3">{tas.date}</span>
                          <h3 class="mx-3">{tas.activity}</h3>
                        </div>
                      </div>
                      <div class="badge">
                        <span>{tas.duration}</span>
                      </div>
                    </div>
                    <div class="mt-3 mx-3">
                      <h5 class="heading text-white">{tas.description}</h5>
                      <div class="mt-3">
                        <div class="progress">
                          <div
                            class="progress-bar"
                            role="progressbar"
                            style={{ width: "100%" }}
                            aria-valuenow="100"
                            aria-valuemin="0"
                            aria-valuemax="100"
                          ></div>
                        </div>
                        <div class="mt-3 pt-2 d-flex justify-content-center">
                          <i
                            class="fa-solid fa-trash-can fa-lg"
                            onClick={() => deleteTask(tas._id)}
                            style={{ cursor: "pointer" }}
                          ></i>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
};

export default History;
