import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState({
    userName: "",
    password: "",
  });

  const submitHandler = async (e) => {
    e.preventDefault();
    let data = await fetch(`http://localhost:8080/register/${user.userName}`);
    data = await data.json();
    if (data.name === user.userName) {
      if (data.password === user.password) {
        localStorage.setItem("user", JSON.stringify(data));
        navigate("/");
      } else {
        alert("Password is Incorrrect");
      }
    } else {
      alert("User not found");
    }
  };
  return (
    <div>
      <section
        class="pt-5 pb-5 mt-0 align-items-center d-flex bg-dark"
        style={{
          minHeight: "100vh",
          backgroundSize: "cover",
          backgroundImage:
            "url(https://images.pexels.com/photos/1552249/pexels-photo-1552249.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1)",
        }}
      >
        <div class="container-fluid ">
          <div class="row  justify-content-center d-flex-row text-center h-100">
            <div class="col-12 col-md-4 col-lg-3 h-50 ">
              <div
                class="card shadow"
                style={{
                  background: "rgba(255, 255, 255,0.1",
                  // border: "2px solid red",
                  color: "yellow",
                  borderRadius: "10px",
                  position: "fixed",
                  bottom: "100px",
                }}
              >
                <div class="card-body mx-auto">
                  <h4 class="card-title mt-3 text-center">Login Now</h4>

                  <form>
                    <div class="form-group input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-envelope"></i>
                        </span>
                      </div>
                      <input
                        name=""
                        class="form-control"
                        placeholder="Enter username..."
                        type="email"
                        onChange={(e) =>
                          setUser({ ...user, userName: e.target.value })
                        }
                      />
                    </div>
                    <div class="form-group input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-lock"></i>
                        </span>
                      </div>
                      <input
                        class="form-control"
                        placeholder="Enter password"
                        type="password"
                        onChange={(e) =>
                          setUser({ ...user, password: e.target.value })
                        }
                      />
                    </div>
                    <p class="mt-0">
                      <Link to="#"> Forget password</Link>
                    </p>
                    <div class="form-check mb-2">
                      <label
                        class="form-check-label"
                        for="flexCheckIndeterminate"
                      >
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value=""
                          id="flexCheckIndeterminate"
                        />
                        Remember me
                      </label>
                    </div>
                    <div class="form-group ">
                      <button
                        onClick={submitHandler}
                        type="submit"
                        class="btn btn-primary btn-block"
                      >
                        Log In
                      </button>
                    </div>
                    <p class="text-center text-white">
                      Have you not account yet?
                      <Link to="/register"> Sign Up</Link>
                    </p>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Login;
