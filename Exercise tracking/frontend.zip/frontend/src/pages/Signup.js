import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

const Signup = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [formErr, setFormErr] = useState({});

  const formValidation = () => {
    let err = {};
    if (name === "") {
      err.name = "name is required";
    }
    if (email === "") {
      err.email = "email is required";
    }
    if (password === "") {
      err.password = "password is required";
    }
    setFormErr({ ...err });
    return Object.keys(err) < 1;
  };
  const handleSubmit = async (e) => {
    console.log("form submission");
    e.preventDefault();

    let isValid = formValidation();

    if (isValid) {
      let data = await fetch(`http://127.0.0.1:8080/register`, {
        method: "POST",
        body: JSON.stringify({ name, email, password }),
        headers: {
          "content-type": "application/json",
        },
      });
      navigate("/login");
      data = await data.json();
    } else {
      alert("Please fill all the information");
    }
  };
  return (
    <div>
      <section
        class="pt-5 pb-5 mt-0 align-items-center d-flex bg-dark"
        style={{
          minHeight: "100vh",
          backgroundSize: "cover",
          backgroundImage:
            "url(https://images.pexels.com/photos/1552249/pexels-photo-1552249.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1)",
        }}
      >
        <div class="container-fluid ">
          <div class="row  justify-content-center align-items-center d-flex-row text-center h-100">
            <div class="col-12 col-md-4 col-lg-3   h-50 ">
              <div
                class="card shadow"
                style={{
                  background: "rgba(255, 255, 255,0.1)",
                  // border: "2px solid red",
                  color: "yellow",
                  borderRadius: "10px",
                }}
              >
                <div class="card-body mx-auto">
                  <h4 class="card-title mt-3 text-center">Sign Up</h4>

                  <form onSubmit={handleSubmit}>
                    <div class="form-group input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-user"></i>
                        </span>
                      </div>
                      <input
                        name=""
                        class="form-control"
                        placeholder="Enter Username"
                        type="text"
                        onChange={(e) => {
                          setName(e.target.value);
                        }}
                      />
                      <p
                        style={{
                          color: "red",
                          margin: "0",
                          padding: "0",
                          textAlign: "end ",
                        }}
                      >
                        {formErr.name}
                      </p>
                    </div>
                    <div class="form-group input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-envelope"></i>
                        </span>
                      </div>
                      <input
                        name=""
                        class="form-control"
                        placeholder="Email address"
                        type="email"
                        onChange={(e) => {
                          setEmail(e.target.value);
                        }}
                      />
                      <p
                        style={{
                          color: "red",
                          margin: "0",
                          padding: "0",
                          textAlign: "end ",
                        }}
                      >
                        {formErr.email}
                      </p>
                    </div>
                    <div class="form-group input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-lock"></i>
                        </span>
                      </div>
                      <input
                        class="form-control"
                        placeholder="Enter password"
                        type="password"
                        onChange={(e) => {
                          setPassword(e.target.value);
                        }}
                      />
                      <p
                        style={{
                          color: "red",
                          margin: "0",
                          padding: "0",
                          textAlign: "end ",
                        }}
                      >
                        {formErr.password}
                      </p>
                    </div>
                    <div class="form-group input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">
                          <i class="fa fa-lock"></i>
                        </span>
                      </div>
                      <input
                        class="form-control"
                        placeholder="Repeat password"
                        type="password"
                      />
                    </div>

                    <div class="form-check mb-2">
                      <label
                        class="form-check-label"
                        for="flexCheckIndeterminate"
                      >
                        <input
                          class="form-check-input"
                          type="checkbox"
                          value=""
                          id="flexCheckIndeterminate"
                        />
                        Remember me
                      </label>
                    </div>
                    <div class="form-group ">
                      <button class="btn btn-primary btn-block">Sign Up</button>
                    </div>
                    <p class="text-center text-white">
                      If you have already account
                      <Link to="/login"> Log In</Link>
                    </p>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Signup;
