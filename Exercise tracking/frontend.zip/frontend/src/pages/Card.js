import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Card = () => {
  const navigate = useNavigate();
  const [activity, setActivity] = useState("");
  const [date, setDate] = useState("");
  const [duration, setDuration] = useState("");
  const [description, setDescription] = useState("");

  const auth = localStorage.getItem("user");
  const user = JSON.parse(auth);

  const handleSubmit = async (e) => {
    e.preventDefault();

    let data = await fetch("http://localhost:8080/activity", {
      method: "POST",
      body: JSON.stringify({
        activity,
        date,
        duration,
        description,
        userId: user._id,
      }),
      headers: {
        "content-type": "application/json",
      },
    });
    navigate("/cardlist");
  };
  return (
    <div>
      <section
        class="pt-5 pb-5 mt-0 align-items-center d-flex bg-dark"
        style={{
          minHeight: "100vh",
          backgroundSize: "cover",
          backgroundImage:
            "url(https://images.squarespace-cdn.com/content/v1/5750d5129f72662d66448028/1472271678722-RMWH483BR8ETEP6LEYJC/Dumbbell+Row+Hold.jpg)",
        }}
      >
        <section>
          <h2 className="text-white">Hi {user.name}</h2>
          <div class="row mx-auto">
            <div class="col-md-8 my-4">
              <div class="card mb-4">
                <div class="card-header py-3 text-center">
                  <h5 class="mb-0">Enter Activity Details</h5>
                </div>
                <div class="card-body">
                  <form onSubmit={handleSubmit}>
                    <div class="row mb-4">
                      <div class="col" style={{ width: "500px" }}>
                        <label class="form-label" for="form6Example2">
                          Select Activity Type
                        </label>
                        <div className="md:w-2/3">
                          <select
                            className="btn btn-secondary dropdown-toggle"
                            id="title"
                            onChange={(e) => {
                              setActivity(e.target.value);
                            }}
                          >
                            <option className="dropdown-item" value="Default">
                              Default
                            </option>
                            <option className="dropdown-item" value="run">
                              Run
                            </option>
                            <option className="dropdown-item" value="swim">
                              Swim
                            </option>
                            <option
                              className="dropdown-item"
                              value="run and Hike"
                            >
                              Run and Hike
                            </option>
                            <option
                              className="dropdown-item"
                              value="bicycle ride"
                            >
                              Bicycle Ride
                            </option>
                          </select>
                        </div>
                      </div>
                      <div class="col">
                        <div class="form-outline">
                          <label class="form-label" for="form6Example2">
                            Date
                          </label>
                          <input
                            type="date"
                            id="form6Example2"
                            class="form-control"
                            onChange={(e) => {
                              setDate(e.target.value);
                            }}
                          />
                        </div>
                      </div>
                    </div>
                    <div class="form-outline mb-4">
                      <label class="form-label" for="form6Example3">
                        Set Duration
                      </label>
                      <input
                        type="number"
                        id="form6Example3"
                        class="form-control"
                        placeholder="In Minutes"
                        required={true}
                        min="1"
                        onChange={(e) => {
                          setDuration(e.target.value);
                        }}
                      />
                    </div>
                    <div class="form-outline mb-4">
                      <label class="form-label" for="form6Example4">
                        Description:
                      </label>
                      <textarea
                        type="text"
                        id="form6Example4"
                        class="form-control"
                        onChange={(e) => {
                          setDescription(e.target.value);
                        }}
                      />
                    </div>

                    <button
                      class="btn btn-primary btn-lg btn-block"
                      type="submit"
                    >
                      Set Activity
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>
      </section>
    </div>
  );
};

export default Card;
