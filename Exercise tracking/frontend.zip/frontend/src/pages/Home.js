import React from "react";
import Carousel from "../components/Carousel";
import Choseus from "../components/Choseus";
import Services from "../components/Services";
import Contactus from "../components/Contactus";

const Home = () => {
  return (
    <div>
      <Carousel />
      <Choseus />
      <Services />
      <Contactus />
    </div>
  );
};

export default Home;
