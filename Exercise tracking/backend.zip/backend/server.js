import express from "express";
import dotenv from "dotenv";
import dbConnection from "./cofig/db.js";
import regUser from "./cofig/regUser.js";
import myActivity from "./cofig/task.js";
import cors from "cors";

const app = express();
app.use(cors());
dotenv.config();

dbConnection();
app.use(express.json());

//for registration of the user.
app.post("/register", async (req, res) => {
  let newUser = new regUser(req.body);
  let result = await newUser.save();
  res.send(result);
});

//compare LOGIN data to the SIGNUP data.
app.get("/register/:username", async (req, res) => {
  let getUser = await regUser.findOne({ name: req.params.username });
  // console.log(getUser);
  if (getUser) {
    res.send(getUser);
  } else {
    res.send({ error: "Record not found" });
  }
});

//Posting the activity data.
app.post("/activity", async (req, res) => {
  let newActivity = new myActivity(req.body);
  let result = await newActivity.save();
  res.send(result);
});

//Getting data from the MongoDB to the task list
app.get("/activities/:id", async (req, res) => {
  let task = await myActivity.find({
    userId: req.params.id,
    complete: false,
  });
  res.send(task);

  // if (todo.length > 0) {
  // } else {
  //   res.send("No single Record found");
  // }
});

// Set Complete the task status

app.put("/activitycomplete/:id", async (req, res) => {
  let result = await myActivity.updateOne(
    { _id: req.params.id },
    { $set: { complete: true } }
  );
  res.send(result);
});

//Getting cards of completed status
app.get("/activity/:id", async (req, res) => {
  let task = await myActivity.find({
    userId: req.params.id,
    complete: true,
  });
  res.send(task);

  // if (todo.length > 0) {
  // } else {
  //   res.send("No single Record found");
  // }
});

//Delete the Task from database.
app.delete("/activity/:id", async (req, res) => {
  let deleteTask = await myActivity.deleteOne({ _id: req.params.id });
  res.send(deleteTask);
});

//Update activity
app.get("/activity/update/:id", async (req, res) => {
  let result = await myActivity.findOne({ _id: req.params.id });

  res.send(result);
});

app.put("/activity/update/:id", async (req, res) => {
  let result = await myActivity.updateOne(
    { _id: req.params.id },
    { $set: req.body }
  );
  res.send(result);
});

const PORT = process.env.PORT;
app.listen(PORT, () => {
  console.log("Server is listening on port " + PORT);
});
