import mongoose from "mongoose";

const dbConnection = async () => {
  let conn = await mongoose.connect(process.env.DB_URL);
  try {
    console.log(`Database connection established ${mongoose.connection.host}`);
  } catch (e) {
    console.log(`Error in DB connection: ${e.message}`);
  }
};

export default dbConnection;
