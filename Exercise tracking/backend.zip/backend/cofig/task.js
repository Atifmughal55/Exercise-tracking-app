import mongoose from "mongoose";

const activitySchema = new mongoose.Schema({
  userId: String,
  activity: String,
  date: Date,
  duration: String,
  description: String,
  complete: {
    type: Boolean,
    default: false,
  },
});

export default mongoose.model("myActivity", activitySchema);
